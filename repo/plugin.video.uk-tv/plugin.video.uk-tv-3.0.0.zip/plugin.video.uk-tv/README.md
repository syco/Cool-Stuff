## Kodi plug-in that plays italian live streams ##

### Introduction ###
A kodi plug-in that scrapes italian links from the web and populate a list understandable by kodi.

### Dependencies ###
- [liveproxy](https://github.com/back-to/liveproxy) for streamlink support

### Help! ###
If you think this piece of code has been useful to you and want to share some love, here's how:

[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=HYNPK8Y2ERW9E)

