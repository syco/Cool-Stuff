from streamlink.plugin.api.http_session import HTTPSession

__all__ = ["HTTPSession"]
